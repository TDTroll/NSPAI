from tkinter import *
from tkinter import ttk
import pyttsx3


### Funciones ###
def RepAud(Texto, Lenguaje):
    engine = pyttsx3.init()
    engine.setProperty('rate', 150)
    engine.setProperty('voice', Lenguaje)
    engine.say(Texto)
    engine.runAndWait()
    engine.stop()


### Clases ###
class TablaLabel:
    def __init__(self, ventana, imin, imax, lista, tci, tce):
        for i in range(imin, imax, 1):
            for j in range(len(lista[1])):
                if j == len(lista[1]) - 1:
                    leng = 'spanish-latin-am'
                    self.e = Button(ventana, width=tce, fg='black', font=('Arial', 12, 'bold'), borderwidth=2,
                                    relief=RIDGE, justify=LEFT, anchor="w", bg="dim gray", bd="1")
                else:
                    leng = 'spanish-latin-am'
                    self.e = Button(ventana, width=tci, fg='black', font=('Arial', 12, 'bold'), borderwidth=2,
                                    relief=RIDGE, justify=LEFT, anchor="w", bg="dim gray", bd="1",
                                    command=lambda texto=lista[i][j]: RepAud(texto, leng))
                self.e.grid(row=i, column=j)
                self.e['text'] = (lista[i][j])


class TablaEntry:
    def __init__(self, ventana, imin, imax, lista):
        for i in range(imin, imax, 1):
            for j in range(len(lista[1])):
                self.e = Entry(ventana, width=20, fg='black', font=('Arial', 14, 'bold'), borderwidth=2,
                               relief=RIDGE, justify=LEFT, anchor="w", bg="dim gray", bd="1")
                if j == 3:
                    self.e = Entry(ventana, width=30, fg='black', font=('Arial', 14, 'bold'), borderwidth=2,
                                   relief=RIDGE, justify=LEFT, anchor="w", bg="dim gray", bd="1")
                self.e.grid(row=i, column=j)
                self.e.insert(END, lista[i][j])


# Ventana Verbos
def verirr():
    secundaria = Tk()
    width = secundaria.winfo_screenwidth()
    height = secundaria.winfo_screenheight()
    secundaria.geometry("%dx%d" % (width, height))
    secundaria.config(bg="black")
    secundaria.title("Verbos irregulares")

    # Comboboxs
    opciones = Frame(secundaria)
    listasL = Label(opciones, text="Número de lista:", fg="white", bg="black", font="Courier 12 bold")
    listasL.pack(side="left")
    listas = ttk.Combobox(opciones, values=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"], state="readonly")
    listas.current(0)
    listas.pack(side="left")
    opciones.pack(side="top", pady=10)
    tablas1 = Frame(secundaria)
    tablas2 = Frame(secundaria)
    tablas2.config(bg="dim gray")
    EncLis = [("Infinitivo/presente", "Pasado simple", "Pasado participio", "Español")]
    tci = 25
    tce = 30
    for j in range(4):
        if j == 3:
            Enc = Label(tablas1, width=tce, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        else:
            Enc = Label(tablas1, width=tci, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        Enc.grid(row=0, column=j)
        Enc['text'] = (EncLis[0][j])
    lista = [('Arise', 'Arose', 'Arisen', 'Surgir, levantar, aumentar'), ('Awake', 'Awoke', 'Awoken', 'Despertar'),
             ('Be, am, are, is', 'Was, Were', 'Been', 'Ser, estar'),
             ('Bear', 'Bore', 'Borne, Born', 'Soportar, dar a luz, resistir'),
             ('Beat', 'Beat', 'Beaten', 'Golpear, derrotar, agotar'),
             ('Become', 'Became', 'Become', 'Llegar a ser, convertir'), ('Begin', 'Began', 'Begun', 'Empezar'),
             ('Bend', 'Bent', 'Bent', 'Doblar, curvar, agachar'), ('Bet', 'Bet', 'Bet', 'Apostar'),
             ('Bind', 'Bound', 'Bound', 'Atar, obligar, unir, ligar'),
             ('Bid', 'Bid', 'Bid', 'Pujar, ofertar, intentar'),
             ('Bite', 'Bit', 'Bitten', 'Morder, picar, atacar, penetrar'),
             ('Bleed', 'Bled', 'Bled', 'Sangrar, sufrir, desteñir'),
             ('Blow', 'Blew', 'Blown', 'Soplar, volar, sonar'),
             ('Break', 'Broke', 'Broken', 'Romper, interrumpir, quebrar'),
             ('Breed', 'Bred', 'Bred', 'Criar, reproducir, engendrar'),
             ('Bring', 'Brought', 'Brought', 'Traer, llevar, provocar, producir'),
             ('Broadcast', 'Broadcast', 'Broadcast', 'Transmitir, difundir, emitir'),
             ('Build', 'Built', 'Built', 'Construir, edificar, fortalecer'),
             ('Burn', 'Burnt, Burned', 'Burnt, Burned', 'Quemar, arder, gastar'),
             ('Burst', 'Burst', 'Burst', 'Reventar, estallar, irrumpir'),
             ('Buy', 'Bought', 'Bought', 'Comprar, sobornar'),
             ('Cast', 'Cast', 'Cast', 'Arrojar, lanzar, emitir, echar'),
             ('Catch', 'Caught', 'Caught', 'Agarrar, atrapar, tomar, capturar'),
             ('Come', 'Came', 'Come', 'Venir, llegar, ser, pasar'),
             ('Cost', 'Cost', 'Cost', 'Costar, valer'), ('Cut', 'Cut', 'Cut', 'Cortar, reducir'),
             ('Choose', 'Chose', 'Chosen', 'Elegir, escoger, seleccionar'),
             ('Cling', 'Clung', 'Clung', 'Adherir, pegar'),
             ('Creep', 'Crept', 'Crept', 'Arrastrar, deslizar, reptar'),
             ('Deal', 'Dealt', 'Dealt', 'Tratar, negociar, traficar, asestar'),
             ('Dig', 'Dug', 'Dug', 'Cavar, comprender, empujar'),
             ('Do  (Does)', 'Did', 'Done', 'Hacer, actuar, cumplir, realizar'),
             ('Draw', 'Drew', 'Drawn', 'Dibujar'), ('Dream', 'Dreamt, Dreamed', 'Dreamt, Dreamed', 'Soñar'),
             ('Drink', 'Drank', 'Drunk', 'Tomar, beber'),
             ('Drive', 'Drove', 'Driven', 'Conducir, dirigir, manejar'),
             ('Eat', 'Ate', 'Eaten', 'Comer, consumir, devorar'),
             ('Fall', 'Fell', 'Fallen', 'Caer, bajar, disminuir'),
             ('Feed', 'Fed', 'Fed', 'Alimentar, cebar'),
             ('Feel', 'Felt', 'Felt', 'Sentir, palpar, tocar'),
             ('Fight', 'Fought', 'Fought', 'Luchar, combatir, lidiar'),
             ('Find', 'Found', 'Found', 'Encontrar, hallar, descubrir'),
             ('Flee', 'Fled', 'Fled', 'Huir, escapar, abandonar'), ('Fly', 'Flew', 'Flown', 'Volar, pilotear'),
             ('Forbid', 'Forbade', 'Forbidden', 'Prohibir, privar, olvidar'),
             ('Forget', 'Forgot', 'Forgotten', 'Olvidar'),
             ('Forgive', 'Forgave', 'Forgiven', 'Perdonar, disculpar'),
             ('Freeze', 'Froze', 'Frozen', 'congelar, helar, pasmar'),
             ('Get', 'Got', 'Got, Gotten', 'Obtener, conseguir, recibir'),
             ('Give', 'Gave', 'Given', 'Dar, ofrecer, prestar'),
             ('Go (Goes)', 'Went', 'Gone', 'Ir, pasar, viajar'),
             ('Grow', 'Grew', 'Grown', 'Crecer, cultivar, aumentar'),
             ('Grind', 'Ground', 'Ground', 'Moler, rechinar, pulverizar, picar'),
             ('Hang', 'Hung', 'Hung', 'Colgar, caer, ahorcar'),
             ('Have', 'Had', 'Had', 'Haber, tener'), ('Hear', 'Heard', 'Heard', 'Oir, escuchar'),
             ('Hide', 'Hid', 'Hidden', 'Ocultar, esconder, disimular'),
             ('Hit', 'Hit', 'Hit', 'Golpear, imparctar, pegar'),
             ('Hold', 'Held', 'Held', 'Agarrar, celebrar, mantener, retener'),
             ('Hurt', 'Hurt', 'Hurt', 'Herir, lastimar, dañar'),
             ('Keep', 'Kept', 'Kept', 'Conservar, mantener'),
             ('Know', 'Knew', 'Known', 'Saber, conocer, reconocer'),
             ('Kneel', 'Knelt', 'Knelt', 'Arrodillar'), ('Knit', 'Knit', 'Knit', 'Tejer, soldarse'),
             ('Lay', 'Laid', 'Laid', 'Poner, colocar, echar'), ('Lead', 'Led', 'Led', 'Conducir, digirir, llevar'),
             ('Lean', 'Leant', 'Leant', 'Apoyar, inclinar'),
             ('Leap', 'Leapt', 'Leapt', 'Brincar, saltar'),
             ('Learn', 'Learnt , Learned', 'Learnt , Learned', 'Aprender'),
             ('Leave', 'Left', 'Left', 'Dejar, salir, abandonar, irse'), ('Lend', 'Lent', 'Lent', 'Prestar, dar'),
             ('Let', 'Let', 'Let', 'Permitir, dejar, alquilar'),
             ('Lie', 'Lay', 'Lain', 'Mentir, echarse, acostarse'),
             ('Light', 'Lit', 'Lit', 'Encender, iluminar, alumbrar'),
             ('Lose', 'Lost', 'Lost', 'Perder, extraviar, deshacer'),
             ('Make', 'Made', 'Made', 'Hacer, fabricar, efectuar'),
             ('Mean', 'Meant', 'Meant', 'Significar, suponer, pretender'),
             ('Meet', 'Met', 'Met', 'Reunir, encontrar, atender'),
             ('Mistake', 'Mistook', 'Mistaken', 'Equivocar, confundir, errar'),
             ('Overcome', 'Overcame', 'Overcome', 'Vencer, superar, salvar, triunfar'),
             ('Pay', 'Paid', 'Paid', 'Pagar, prestar, rendir, abonar'),
             ('Put', 'Put', 'Put', 'Poner, colocar, dejar '),
             ('Read', 'Read', 'Read', 'Leer, consultar, interpretar'),
             ('Ride', 'Rode', 'Ridden', 'Montar, cabalgar, viajar'),
             ('Ring', 'Rang', 'Rung', 'Llamar, sonar'), ('Rise', 'Rose', 'Risen', 'Levantarse, subir, ascender'),
             ('Run', 'Ran', 'Run', 'Correr, funcionar, ejecutar'),
             ('Say', 'Said', 'Said', 'Decir, afirmar, expresar'),
             ('See', 'Saw', 'Seen', 'Ver, consultar, mirar, conocer'),
             ('Seek', 'Sought', 'Sought', 'Buscar, solicitar'),
             ('Sell', 'Sold', 'Sold', 'Vender, expender'), ('Send', 'Sent', 'Sent', 'Enviar, mandar, lanzar'),
             ('Set', 'Set', 'Set', 'Poner(se), colocar, fijar, ajustar'),
             ('Sew', 'Sewed', 'Sewed, Sewn', 'Coser, encuadernar'),
             ('Shake', 'Shook', 'Shaken', 'Sacudir, agitar, temblar'),
             ('Shear', 'Shore', 'Shorn', 'Cortar, esquilar, transquilar, pelar'),
             ('Shine', 'Shone', 'Shone', 'Brillar, resplandecer, lucir'),
             ('Shoot', 'Shot', 'Shot', 'Disparar, tirar, arrojar'),
             ('Show', 'Showed', 'Shown', 'Mostrar, demostar, aparecer'),
             ('Shrink', 'Shrank', 'Shrunk', 'Encogerse, contraer, reducir, disminuir'),
             ('Shut', 'Shut', 'Shut', 'Cerrar, encerrar'),
             ('Sing', 'Sang', 'Sung', 'Cantar, silbar, zumbar'), ('Sink', 'Sank', 'Sunk', 'Hundir, caer'),
             ('Sit', 'Sat', 'Sat', 'Sentarse'),
             ('Sleep', 'Slept', 'Slept', 'Dormir, entumecer'), ('Slide', 'Slid', 'Slid', 'Resbalar, deslizar'),
             ('Smell', 'Smelt', 'Smelt', 'Oler, olfatear, heder'),
             ('Sow', 'Sowed', 'Sowed, Sown', 'Sembrar, esparcir'),
             ('Speak', 'Spoke', 'Spoken', 'Hablar, decir, intervenir, sonar'),
             ('Speed', 'Sped', 'Sped', 'Acelerar, apresurar'),
             ('Spell', 'Spelt', 'Spelt', 'Deletrear, significar, presagiar'),
             ('Spend', 'Spent', 'Spent', 'Gastar, agotar'),
             ('Spill', 'Spilt, Spilled', 'Spilt, Spilled', 'Derramar, verter, volcar'),
             ('Spin', 'Spun', 'Spun', 'Girar, hilar'),
             ('Spit', 'Spat', 'Spat', 'Escupir, ensartar, bufar'),
             ('Split', 'Split', 'Split', 'Separar, partir, rajar, dividir'),
             ('Spoil', 'Spoilt, Spoiled', 'Spoilt, Spoiled', 'Estropear, deteriorar, mimar'),
             ('Spread', 'Spread', 'Spread', 'Extender, propagar, untar'),
             ('Spring', 'Sprang', 'Sprung', 'Saltar, brotar, brincar'),
             ('Stand', 'Stood', 'Stood', 'Estar en pie, aguntar, tolerar'),
             ('Steal', 'Stole', 'Stolen', 'Robar, hurtar, refalar'),
             ('Stick', 'Stuck', 'Stuck', 'Pegar, adherir, estancar'),
             ('Sting', 'Stung', 'Stung', 'Picar, punzar, resquemar'),
             ('Stink', 'Stank,Stunk', 'Stunk', 'Apestar, heder'),
             ('Stride', 'Strode', 'Stridden', 'Dar zancadas'),
             ('Strike', 'Struck', 'Struck', 'Golpear, atacar, percutir'),
             ('Swear', 'Swore', 'Sworn', 'Jurar, maldecir, prestar'),
             ('Sweat', 'Sweat', 'Sweat', 'Sudar, explotar'),
             ('Sweep', 'Swept', 'Swept', 'Barrer, precipitar, dragar'),
             ('Swell', 'Swelled', 'Swollen', 'Hinchar, crecer, inflar'),
             ('Swim', 'Swam', 'Swum', 'Nadar'), ('Swing', 'Swung', 'Swung', 'Columpiar, oscilar, balancear'),
             ('Take', 'Took', 'Taken', 'Tomar, llevar, aprovechar'), ('Teach', 'Taught', 'Taught', 'Enseñar'),
             ('Tear', 'Tore', 'Torn', 'Rasgar, desgarrar, arrancar'),
             ('Tell', 'Told', 'Told', 'Contar, decir, informar'),
             ('Think', 'Thought', 'Thought', 'Pensar, imaginar, creer, reflexionar'),
             ('Throw', 'Threw', 'Thrown', 'Arrojar, tirar'),
             ('Thrust', 'Thrust', 'Thrust', 'Impulsar, empujar, introducir'),
             ('Tread', 'Trod', 'Trodden', 'Pisar, hollar, enhebrar, ensartar'),
             ('Understand', 'Understood', 'Understood', 'Entender, comprender, captar'),
             ('Undergo', 'Underwent', 'Undergone', 'Sufrir, someter, padecer'),
             ('Undertake', 'Undertook', 'Undertaken', 'Emprender, comprometerse'),
             ('Wake', 'Woke', 'Woken', 'Despertar, velar'),
             ('Wear', 'Wore', 'Worn', 'usar, llevar puesto, vestir'),
             ('Weave', 'Wove', 'Woven', 'Tejer, entrelazar, urdir'),
             ('Weep', 'Wept', 'Wept', 'Llorar'), ('Wet', 'Wet', 'Wet', 'Mojar, humedecer, refrescar'),
             ('Win', 'Won', 'Won', 'Ganar, triunfar, lograr'),
             ('Wind', 'Wound', 'Wound', 'Enrollar, devanar, girar'),
             ('Withdraw', 'Withdrew', 'Withdrawn', 'Retirar, abandonar, esquivar'),
             ('Wring', 'Wrung', 'Wrung', 'Torcer, exprimir, escurrir, apenar'),
             ('Write', 'Wrote', 'Written', 'Escribir, redactar, componer')]
    imin = 0
    imax = 14

    def seltab(event):
        corte = int(event.widget.get())
        if corte == 1:
            imin = 0
            imax = 14
        elif corte == 2:
            imin = 14
            imax = 28
        elif corte == 3:
            imin = 28
            imax = 42
        elif corte == 4:
            imin = 42
            imax = 56
        elif corte == 5:
            imin = 56
            imax = 70
        elif corte == 6:
            imin = 70
            imax = 84
        elif corte == 7:
            imin = 84
            imax = 98
        elif corte == 8:
            imin = 98
            imax = 112
        elif corte == 9:
            imin = 112
            imax = 126
        elif corte == 10:
            imin = 126
            imax = 140
        else:
            imin = 140
            imax = 154
        for widget in tablas2.winfo_children():
            widget.destroy()
        t = TablaLabel(tablas2, imin, imax, lista, tci, tce)

    listas.bind("<<ComboboxSelected>>", seltab)
    t = TablaLabel(tablas2, imin, imax, lista, tci, tce)
    tablas1.pack()
    tablas2.pack()

    secundaria.mainloop()


def verreg():
    secundaria = Tk()
    width = secundaria.winfo_screenwidth()
    height = secundaria.winfo_screenheight()
    secundaria.geometry("%dx%d" % (width, height))
    secundaria.config(bg="black")
    secundaria.title("Verbos regulares")

    # Comboboxs
    opciones = Frame(secundaria)
    listasL = Label(opciones, text="Número de lista:", fg="white", bg="black", font="Courier 12 bold")
    listasL.pack(side="left")
    listas = ttk.Combobox(opciones, values=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"], state="readonly")
    listas.current(0)
    listas.pack(side="left")
    opciones.pack(side="top", pady=10)
    tablas1 = Frame(secundaria)
    tablas2 = Frame(secundaria)
    tablas2.config(bg="dim gray")
    EncLis = [("Infinitivo/presente", "Pasado simple/paricipio", "Español")]
    tci = 25
    tce = 35
    for j in range(3):
        if j == 2:
            Enc = Label(tablas1, width=tce, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        else:
            Enc = Label(tablas1, width=tci, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        Enc.grid(row=0, column=j)
        Enc['text'] = (EncLis[0][j])
    lista = [('Act', 'Acted', 'Actuar'), ('Add', 'Added', 'Añadir'), ('Arrest', 'Arrested', 'Arrestar'),
             ('Assist', 'Assisted', 'Asistir'), ('Address', 'Addressed', 'Dirigirse'),
             ('Advertise', 'Advertised', 'Anunciar'), ('Amuse', 'Amused', 'Entretener'),
             ('Approach', 'Approached', 'Acercarse'), ('Ask', 'Asked', 'Preguntar'), ('Agree', 'Agreed', 'Concordar'),
             ('Annoy', 'Annoyed', 'Molestar'), ('Answer', 'Answered', 'Responder'), ('Appear', 'Appeared', 'Aparecer'),
             ('Arrange', 'Arranged', 'Arreglar'), ('Arrive', 'Arrived', 'Llegar'),
             ('Abandon', 'Abandoned', 'Abandonar'), ('Abuse', 'Abused', 'Abusar'), ('Acquire', 'Acquired', 'Adquirir'),
             ('Admire', 'Admired', 'Admirar'), ('Adore', 'Adored', 'Adorar'), ('Advance', 'Advanced', 'Avanzar'),
             ('Advice', 'Adviced', 'Aconsejar'), ('Announce', 'Announced', 'Anunciar'),
             ('Attempt', 'Attempted', 'Intentar'), ('Avoid', 'Avoided', 'Evitar'), ('Attack', 'Attacked', 'Atacar'),
             ('Assure', 'Assured', 'Asegurar'), ('Apologize', 'Apologized', 'Disculparse'),
             ('Allow', 'Allowed', 'Permitir'), ('Admit', 'Admited', 'Admitir'), ('Accuse', 'Accused', 'Acusar'),
             ('Accede', 'Acceded', 'Acceder'), ('Absorb', 'Absorbed', 'Absorber'), ('Abolish', 'Abolished', 'Abolir'),
             ('Accent', 'Accented', 'Acentuar'), ('Beg', 'Begged', 'Rogar'), ('Believe', 'Believed', 'Creer'),
             ('Blame', 'Blamed', 'Culpar'), ('Belong', 'Belonged', 'Pertenecer'), ('Balance', 'Balanced', 'Equilibrar'),
             ('Bless', 'Blessed', 'Bendecir'), ('Brush', 'Brushed', 'Cepillar'), ('Behave', 'Behaved', 'Comportarse'),
             ('Breathe', 'Breathed', 'Respirar'), ('Complete', 'Completed', 'Completar'),
             ('Consist', 'Consisted', 'Consistir'), ('Count', 'Counted', 'Contar'), ('Close', 'Closed', 'Cerrar'),
             ('Cook', 'Cooked', 'Cocinar'), ('Crash', 'Crashed', 'Chocar'), ('Cross', 'Crossed', 'Cruzar'),
             ('Call', 'Called', 'Llamar'), ('Care', 'Cared', 'Cuidar'), ('Carry', 'Carried', 'Llevar'),
             ('Change', 'Changed', 'Cambiar'), ('Check', 'Checked', 'Chequear'), ('Charge', 'Charged', 'Cargar'),
             ('Clean', 'Cleaned', 'Limpiar'), ('Climb', 'Climbed', 'Escalar'), ('Cover', 'Covered', 'Cubrir'),
             ('Cry', 'Cried', 'Llorar'), ('Cash', 'Cashed', 'Cobrar'), ('Claim', 'Claimed', 'Reclamar'),
             ('Command', 'Commanded', 'Mandar'), ('Compare', 'Compared', 'Comparar'),
             ('Compose', 'Composed', 'Componer'), ('Consider', 'Considered', 'Considerar'),
             ('Contain', 'Contained', 'Contener'), ('Copy', 'Copied', 'Copiar'), ('Crown', 'Crowned', 'Coronar'),
             ('Continue', 'Continued', 'Continuar'), ('Commit', 'Commited', 'Cometer'),
             ('Combine', 'Combined', 'Combinar'), ('Collect', 'Collected', 'Colectar'), ('Dance', 'Danced', 'Bailar'),
             ('Dress', 'Dressed', 'Vestir'), ('Dropp', 'Dropped', 'Dejar Caer'), ('Die', 'Died', 'Morir'),
             ('Declare', 'Declared', 'Declarar'), ('Delay', 'Delayed', 'Demorar'), ('Deliver', 'Delivered', 'Entregar'),
             ('Deny', 'Denied', 'Denegar'), ('Dry', 'Dried', 'Secar'), ('Destroy', 'Destroyed', 'Destruir'),
             ('Devote', 'Devoted', 'Dedicar'), ('Enjoy', 'Enjoyed', 'Disfrutar'), ('Engage', 'Engaged', 'Comprometer'),
             ('Envy', 'Envied', 'Envidiar'), ('Express', 'Expressed', 'Expresar'), ('Exclaim', 'Exclaimed', 'Exclamar'),
             ('Explain', 'Explained', 'Explicar'), ('Fail', 'Failed', 'Fracasar'), ('File', 'Filed', 'Archivar'),
             ('Fire', 'Fired', 'Despedir'), ('Fill', 'Filled', 'Llenar'), ('Follow', 'Followed', 'Seguir'),
             ('Fry', 'Fried', 'Freir'), ('Finish', 'Finished', 'Terminar'), ('Fish', 'Fished', 'Pescar'),
             ('Fix', 'Fixed', 'Arreglar'), ('Gain', 'Gained', 'Ganar'), ('Guess', 'Guessed', 'Adivinar'),
             ('Help', 'Helped', 'Ayudar'), ('Hope', 'Hope', 'Desear'), ('Happen', 'Happened', 'Suceder'),
             ('Hurry', 'Hurried', 'Apurarse'), ('Imagine', 'Imagined', 'Imaginar'), ('Judge', 'Judged', 'Juzgar'),
             ('Kiss', 'Kissed', 'Besar'), ('Kill', 'Killed', 'Matar'), ('Laugh', 'Laughed', 'Reir'),
             ('Like', 'Liked', 'Gustar'), ('Look', 'Looked', 'Mirar'), ('Mark', 'Marked', 'Marcar'),
             ('Miss', 'Missed', 'Extrañar'), ('Manage', 'Managed', 'Manejar'), ('Maintain', 'Maintained', 'Mantener'),
             ('Marry', 'Married', 'Casarse'), ('Massage', 'Massaged', 'Masajear'), ('Measure', 'Measured', 'Medir'),
             ('Move', 'Moved', 'Mover'), ('Notice', 'Notice', 'Notificar'), ('Number', 'Numbered', 'Enumerar'),
             ('Name', 'Named', 'Nombrar'), ('Note', 'Noted', 'Notar'), ('Observe', 'Observed', 'Observar'),
             ('Offer', 'Offered', 'Ofrecer'), ('Open', 'Opened', 'Abrir'), ('Order', 'Ordered', 'Ordenar'),
             ('Perform', 'Performed', 'Ejecutar'), ('Phone', 'Phoned', 'Telefonear'), ('Plan', 'Planned', 'Planificar'),
             ('Play', 'Played', 'Jugar'), ('Pray', 'Prayed', 'Orar'), ('Prefer', 'Prefered', 'Preferir'),
             ('Prepare', 'Prepared', 'Preparar'), ('Park', 'Parked', 'Estacionar'), ('Pass', 'Passed', 'Pasar'),
             ('Pick', 'Picked', 'Recoger'), ('Please', 'Pleased', 'Complacer'), ('Practice', 'Practiced', 'Practicar'),
             ('Promise', 'Promised', 'Prometer'), ('Pronounce', 'Pronounced', 'Pronunciar'),
             ('Punish', 'Punished', 'Castigar'), ('Push', 'Pushed', 'Empujar'), ('Repeat', 'Repeated', 'Repetir'),
             ('Report', 'Reported', 'Reportar'), ('Request', 'Requested', 'Solicitar'),
             ('Refuse', 'Refused', 'Rechazar'), ('Raise', 'Raised', 'Levantar'),
             ('Register', 'Registered', 'Registrar'), ('Receive', 'Received', 'Recibir'),
             ('Remember', 'Remembered', 'Recordar'), ('Repair', 'Repaired', 'Reparar'),
             ('Require', 'Required', 'Requerir'), ('Reserve', 'Reserved', 'Reservar'),
             ('Resolve', 'Resolved', 'Resolver'), ('Search', 'Searched', 'Buscar'), ('Save', 'Saved', 'Salvar'),
             ('Serve', 'Served', 'Servir'), ('Sign', 'Signed', 'Firmar'), ('Smile', 'Smiled', 'Sonreír'),
             ('Stay', 'Stayed', 'Permanecer'), ('Study', 'Studied', 'Estudiar'), ('Suffer', 'Suffered', 'Sufrir'),
             ('Smoke', 'Smoked', 'Fumar'), ('Stop', 'Stopped', 'Detener'), ('Start', 'Started', 'Comenzar'),
             ('Sound', 'Sounded', 'Sonar'), ('Surprise', 'Surprised', 'Sorprender'), ('Sail', 'Sailed', 'Navegar'),
             ('Talk', 'Talked', 'Conversar'), ('Touch', 'Touched', 'Tocar'), ('Train', 'Trained', 'Entrenar'),
             ('Taste', 'Tasted', 'Probar'), ('Translate', 'Translated', 'Traducir'), ('Travel', 'Traveled', 'Viajar'),
             ('Trouble', 'Troubled', 'Molestar'), ('Tie', 'Tied', 'Atar'), ('Test', 'Tested', 'Probar'),
             ('Try', 'Tried', 'Intentar'), ('Trust', 'Trusted', 'Confiar'), ('Turn', 'Turned', 'Girar'),
             ('Use', 'Used', 'Usar'), ('Unite', 'United', 'Unir'), ('Visit', 'Visited', 'Visitar'),
             ('Vary', 'Varied', 'Variar'), ('Wait', 'Waited', 'Esperar'), ('Want', 'Wanted', 'Querer'),
             ('Walk', 'Walked', 'Caminar'), ('Wash', 'Washed', 'Lavar'), ('Watch', 'Watched', 'Observar'),
             ('Wish', 'Wished', 'Desear'), ('Work', 'Worked', 'Trabajar'), ('Warm', 'Warmed', 'Calentar'),
             ('Water', 'Watered', 'Regar'), ('Weigh', 'Weighed', 'Pesar'), ('Whistle', 'Whistled', 'Silbar'),
             ('Worry', 'Worried', 'Preocuparse'), ('Wound', 'Wounded', 'Herir')]
    imin = 0
    imax = 20

    def seltab(event):
        corte = int(event.widget.get())
        if corte == 1:
            imin = 0
            imax = 20
        elif corte == 2:
            imin = 20
            imax = 40
        elif corte == 3:
            imin = 40
            imax = 60
        elif corte == 4:
            imin = 60
            imax = 80
        elif corte == 5:
            imin = 80
            imax = 100
        elif corte == 6:
            imin = 100
            imax = 120
        elif corte == 7:
            imin = 120
            imax = 140
        elif corte == 8:
            imin = 140
            imax = 160
        elif corte == 9:
            imin = 160
            imax = 180
        else:
            imin = 180
            imax = 200
        for widget in tablas2.winfo_children():
            widget.destroy()
        t = TablaLabel(tablas2, imin, imax, lista, tci, tce)

    listas.bind("<<ComboboxSelected>>", seltab)
    t = TablaLabel(tablas2, imin, imax, lista, tci, tce)
    tablas1.pack()
    tablas2.pack()

    secundaria.mainloop()


def verphr():
    secundaria = Tk()
    width = secundaria.winfo_screenwidth()
    height = secundaria.winfo_screenheight()
    secundaria.geometry("%dx%d" % (width, height))
    secundaria.config(bg="black")
    secundaria.title("Verbos compuestos")

    # Comboboxs
    opciones = Frame(secundaria)
    listasL = Label(opciones, text="Número de lista:", fg="white", bg="black", font="Courier 12 bold")
    listasL.pack(side="left")
    listas = ttk.Combobox(opciones, values=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"], state="readonly")
    listas.current(0)
    listas.pack(side="left")
    opciones.pack(side="top", pady=10)
    tablas1 = Frame(secundaria)
    tablas2 = Frame(secundaria)
    tablas2.config(bg="dim gray")
    EncLis = [("Infinitivo/presente", "Español")]
    tci = 60
    tce = 70
    for j in range(2):
        if j == 1:
            Enc = Label(tablas1, width=tce, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        else:
            Enc = Label(tablas1, width=tci, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        Enc.grid(row=0, column=j)
        Enc['text'] = (EncLis[0][j])
    lista = [('Get on', 'Subir/montarse'), ('Drive off', 'Marcharse (en un vehículo) de algún lugar'),
             ('Come back', 'Volver a algún lugar'), ('Break down', 'Dejar de funcionar u operar (romperse)'),
             ('Look out', 'Ser cuidadoso, permanecer atento'), ('Take off', 'Despegar'),
             ('Get on', 'Ponerse, Llevarse (bien/mal) con alguien, llevar algo'), ('Get by', 'Arreglárselas'),
             ('Run away', 'Escaparse, huir, alejarse'), ('Keep up', 'Llevar el ritmo'),
             ('Look up', 'Fijarse en algo'), ('Look forward', 'Estar pendiente/emocionado'),
             ('Get in', 'Entrar'), ('Let yourself in', 'Dejar entrar a alguien'),
             ('Dive in', 'Bucear, zambullirse, sumergirse'), ('Move in', 'Mudarse, avanzar'),
             ('Check in', 'Presentar documentos, registrarse'),
             ('Walk out', 'Irse de algún lugar de repente'), ('Lock out', 'Quedarse encerrado, no poder entrar'),
             ('Climb out', 'Salir/subir con dificultades'), ('Check out', 'Comprobar algo, pagar la cuenta'),
             ('Drop in, Call in', 'Visitar/encontrarse a alguien sin tener intención previa '),
             ('Join in', 'Tomar parte en algún tipo de actividad que se está llevando'),
             ('Plug in', 'Conectar algo a otra cosa'),
             ('Fill in, Fill out', 'Rellenar un formulario o documento'),
             ('Take in', 'Engañar, ser engañado'), ('Eat out', 'Comer fuera'),
             ('Drop out', 'Dejar de hacer algo justo antes de terminar'),
             ('Get out', 'Evitar hacer algo, no tener que hacer algo nunca más'),
             ('Cut out', 'Recortar algo de un periódico o una revista'),
             ('Leave out', 'Omitir algo, no incluirlo'),
             ('Cross out, Rub out', 'Dibujar una línea para incluir o excluir'),
             ('Go out', 'Apagar solo, hacer un esfuerzo, salir, pasar de moda'),
             ('Put out', 'Extinguir, apagar algo'), ('Turn out', 'Apagar (luces)'),
             ('Blow out', 'Apagar (fuego, velas), reventar algo (explosión), vaciar'),
             ('Work out', 'Hacer ejercicio físico'), ('Work out', 'Desarrollarse, progresar, elaborar'),
             ('Work out ', 'Calcular, pensar y solucionar problema'),
             ('Carry out', 'Hacer algo y finalizarlo'),
             ('Fall out', 'Dejar de ser amigos'),
             ('Find out that, Find out what', 'Recoger, descubrir, recopilar (hechos)'),
             ('Give out, Hand out', 'Dar a cada persona, distribuir'),
             ('Point out', 'Poner atención, fijarse o señalar'), ('Run out ', 'Acabar, quedarse, vaciar'),
             ('Sort out', 'Solucionar, poner algo en orden'), ('Turn out to be', 'Tener razón'),
             ('Turn out good,Turn out nice', 'Que algo mejore (el tiempo)'), ('Turn out that', 'Resultó ser que…'),
             ('Try out', 'Comprobar que todo está bien'), ('Go on', 'Algo que pasa/ocurre'),
             ('Call off', 'Cancelar algo'), ('Put off', 'Retrasar algo, posponerlo'),
             ('Put off', 'Retrasar algo, posponerlo'), ('Put on', 'Vestir algo, ponerse algo'),
             ('Put on', 'Coger kilos, ganar peso'), ('Try on', 'Probarse ropa'),
             ('Take off', 'Quitarse, desvestirse'),
             (' Be off', 'Estará alguien en un lugar y momento concreto'),
             ('Walk off, Run off, Drive off, Ride off', 'Irse (caminando, corriendo, etc'),
             ('Set off', 'Comenzar un camino/viaje/recorrido'), ('Take off', 'Despegar del suelo (avión)'),
             ('See off', 'Acompañar a alguien para despedirte'),
             ('Drive on, Walk on, Play on', 'Continuar andando/conduciendo/Jugando'), ('Go on', 'Continuar'),
             ('Go on, carry on', 'Continuar (haciendo algo)'),
             ('Go on with, carry on with', 'Continuar (haciendo algo)'),
             ('Keep on', 'Hacer algo repetidamente (siempre)'), ('Get on', 'Hacer progresos'),
             ('Get on', 'Tener una buena relación'),
             ('Get on', 'Continuar después de interrupción'), ('Doze off, Drop off, Nod off', 'Caer dormido'),
             ('Finish off', 'Hacer la última parte de algo'), ('Go off', 'Que algo explote'),
             ('Go off', 'Sonar, que algo suene'), ('Put off', 'Sin ganas, disuadir, cansar'),
             ('Rip off', 'Engañar a alguien (informal)'), ('Show off', 'Impresionar, lucirse, exhibirse'),
             ('Tell off', 'Regañar'), ('Put up', 'Colgar, poner en algún sitio'),
             ('Pick up', 'Recoger'), ('Stand up', 'Levantarse'), ('Turn up', 'Elevar, subir'),
             ('Take down', 'Bajar, quitar algo de algún sitio'),
             ('Put down', 'Soltar, dejar, depositar'),
             ('Sit down, Bend down, Lie down', 'Sentarse, tumbarse, agacharse'), ('Turn down', 'Bajar algo, reducir'),
             ('Knock down, Blow down, Cut down', 'Demoler, tirar, echar abajo'),
             ('Knocked down', 'Noquear, tumbar, golpear, dejar inconsciente'),
             ('Slow down', 'Reducir la velocidad, ir mas despacio'), ('Calme down', 'Calmarse, calmar a alguien'),
             ('Cut down', 'Hacer algo menos de la costumbre'),
             ('Break down', 'Dejar de funcionar (máquinas, coches, etc'),
             ('Close down, Shut down', 'Cerrar un negocio, apagar'),
             ('Let down', 'Defraudar o decepcionar a alguien'),
             ('Turn down', 'Rechazar a algo o alguien'),
             ('Write down', 'Escribir algo para recordar'), ('Go up, come up, walk up', 'Acercarse, acelerar'),
             ('Catch up', 'Alcanzar velocidad o nivel determinado'),
             ('Set up', 'Designar, elegir, seleccionar'),
             ('Take up', 'Comenzar algo'), ('Fix up', 'Organizar, arreglar'),
             ('Grow up', 'Crecer, hacerse mayor'), ('Bring up', 'Levantar, cuidar a un niño, hacerse cargo'),
             ('Clean up, Clear up, Tidy up', 'Dejar algo limpio, recogido'),
             ('Wash up', 'Limpiar los platos y cubiertos después de comer'),
             ('End up', 'Terminar algo que se está haciendo'), ('Give up', 'Rendirse'),
             ('Give up', 'Dejar de hacer algo'), ('Make up', 'Formar parte de algo, maquillar, inventar'),
             ('Be made up', 'Estar hecho de algo'),
             ('Take up', 'Usar el espacio o el tiempo'), ('Turn up, Show up', 'Llegar, aparecer, mostrar'),
             ('Use up', 'Usar la totalidad de algo sin que quede nada'),
             ('Bring up', 'Introducir, mencionar algo (tema)'),
             ('Come up', 'Introducir algo en una conversación'),
             ('Make up', 'Contar mentiras'), ('Cheer up', 'Alegrarse'),
             ('Cheer up', 'Hacer que alguien se sienta mejor'),
             ('Save up', 'Guardar algo para otra cosa'),
             ('Clear up', 'Que algo se aclare (para el tiempo)'), ('Blow up', 'Que algo explote'),
             ('Blow up', 'Destruir algo con una bomba'),
             ('Tear up', 'Despedazar, romper, partir (en pedazos)'),
             ('Beat up', 'Noquear, golpear con ánimo de hacer daño'),
             ('Break up, Split up', 'Terminar (con alguien)'),
             ('Do up', 'Abrochar, atar, amarrar'),
             ('Do up', 'Reparar y mejorar algo, renovar'),
             ('Look up', 'Comprobar, buscar'),
             ('Put up', 'Tolerar, soportar, aguantar algo'),
             ('Hold up', 'Retrasar a alguien o a algo'),
             ('Mix up, get mixed up', 'Confundirse'), ('Away ', 'Lejos de casa'),
             ('Away ', 'Lejos de un lugar, de una persona'), ('Back ', 'Volver a casa'),
             ('Back ', 'Volver a algún lugar, o volver con alguna persona'),
             ('Get away', 'Escapar, salir de algún sitio con dificultades'),
             ('Get away', 'Hacer algo malo sin ser descubierto'),
             ('Keep away', 'Mantenerse lejos'),
             ('Give away', 'Darle algo a alguien porque ya no lo quieres'),
             ('Put away', 'Esconder'), ('Throw away', 'Tirar algo a la basura'),
             ('Wave back, Smile back, Shout back, Write back, Hit back', 'Devolver un saludo, etc'),
             ('Call back, Phone back, Ring back', 'Devolver una llamada, etc'),
             ('Get back', 'Responder a alguien'),
             ('Look back', 'Pensar sobre algo que ha pasado con '),
             ('Pay back', 'Devolver dinero'), ('Pay somebody back', 'Devolver dinero a alguien'),
             ('Turn round', 'Cambiar de dirección, girarse'), ('Mess Up', 'Arruinar')]
    imin = 0
    imax = 15

    def seltab(event):
        corte = int(event.widget.get())
        if corte == 1:
            imin = 0
            imax = 15
        elif corte == 2:
            imin = 15
            imax = 30
        elif corte == 3:
            imin = 30
            imax = 45
        elif corte == 4:
            imin = 45
            imax = 60
        elif corte == 5:
            imin = 60
            imax = 75
        elif corte == 6:
            imin = 75
            imax = 90
        elif corte == 7:
            imin = 90
            imax = 105
        elif corte == 8:
            imin = 105
            imax = 120
        elif corte == 9:
            imin = 120
            imax = 135
        else:
            imin = 135
            imax = 150
        for widget in tablas2.winfo_children():
            widget.destroy()
        t = TablaLabel(tablas2, imin, imax, lista, tci, tce)

    listas.bind("<<ComboboxSelected>>", seltab)
    t = TablaLabel(tablas2, imin, imax, lista, tci, tce)
    tablas1.pack()
    tablas2.pack()

    secundaria.mainloop()


def sus():
    secundaria = Tk()
    width = secundaria.winfo_screenwidth()
    height = secundaria.winfo_screenheight()
    secundaria.geometry("%dx%d" % (width, height))
    secundaria.config(bg="black")
    secundaria.title("Sustantivos")

    # Comboboxs
    opciones = Frame(secundaria)
    listasL = Label(opciones, text="Número de lista:", fg="white", bg="black", font="Courier 12 bold")
    listasL.pack(side="left")
    listas = ttk.Combobox(opciones, values=["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"], state="readonly")
    listas.current(0)
    listas.pack(side="left")
    opciones.pack(side="top", pady=10)
    tablas1 = Frame(secundaria)
    tablas2 = Frame(secundaria)
    tablas2.config(bg="dim gray")
    EncLis = [("Inglés", "Español")]
    tci = 20
    tce = 20
    for j in range(2):
        if j == 1:
            Enc = Label(tablas1, width=tce, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        else:
            Enc = Label(tablas1, width=tci, fg='yellow', font=('Arial', 12, 'bold'), borderwidth=2,
                        relief=RIDGE, justify=LEFT, anchor="w", bg="black", bd="3")
        Enc.grid(row=0, column=j)
        Enc['text'] = (EncLis[0][j])
    lista = [('action', 'acción'), ('age', 'edad'), ('air', 'aire'), ('animal', 'animal'), ('answer', 'respuesta'),
             ('apple', 'manzana'), ('art', 'arte'), ('baby', 'bebé'), ('back', 'espalda'), ('ball', 'bola, pelota'),
             ('bank', 'banco'), ('bed', 'cama'), ('bill', 'factura'), ('bird', 'pájaro'), ('blood', 'sangre'),
             ('boat', 'barco'), ('body', 'cuerpo'), ('bone', 'hueso'), ('book', 'libro'),
             ('bottom', 'fondo, parte bajo'), ('box', 'caja'), ('boy', 'niño (masculino)'), ('brother', 'hermano'),
             ('building', 'edificio'), ('business', 'negocio'), ('call', 'llamada'), ('capital', 'capital'),
             ('case', 'caso, estuche'), ('cat', 'gato'), ('cause', 'causa'), ('cent', 'céntimo'), ('center', 'centro'),
             ('century', 'siglo'), ('chance', 'oportunidad'), ('change', 'cambio'), ('check', 'cheque'),
             ('child', 'niño'), ('church', 'iglesia'), ('circle', 'círculo'), ('city', 'ciudad'),
             ('class', 'clase, curso'), ('clothes', 'ropa'), ('cloud', 'nube'), ('coast', 'costa'), ('color', 'color'),
             ('company', 'empresa'), ('consonant', 'consonante'), ('copy', 'copia'), ('corn', 'maíz'),
             ('cotton', 'algodón'), ('country', 'país, campo'), ('course', 'curso'), ('cow', 'vaca'),
             ('crowd', 'multitud'), ('day', 'día'), ('dictionary', 'diccionario'), ('direction', 'dirección'),
             ('distance', 'distancia'), ('doctor', 'médico'), ('dollar', 'dólar'), ('door', 'puerta'), ('ear', 'oreja'),
             ('earth', 'tierra'), ('egg', 'huevo'), ('energy', 'energía'), ('example', 'ejemplo'),
             ('experience', 'experiencia'), ('eye', 'ojo'), ('game', 'juego, partido'), ('garden', 'jardín'),
             ('gas', 'carburante'), ('girl', 'chica, niña'), ('glass', 'vidrio, vaso'), ('gold', 'oro'),
             ('government', 'gobierno'), ('grass', 'hierba, césped'), ('group', 'grupo'), ('hair', 'pelo'),
             ('hand', 'mano'), ('hat', 'sombrero'), ('head', 'cabeza'), ('heart', 'corazón'),
             ('heat', 'calor, calefacción'), ('history', 'historia'), ('hole', 'agujero, hueco'),
             ('home', 'casa, hogar'), ('horse', 'caballo'), ('hour', 'hora'), ('house', 'casa'), ('ice', 'hielo'),
             ('idea', 'idea'), ('inch', 'pulgada'), ('industry', 'industria'), ('information', 'información'),
             ('insect', 'insecto'), ('interest', 'interés'), ('iron', 'hierro, plancha'), ('island', 'isla'),
             ('job', 'puesto de trabajo'), ('key', 'llave'), ('lake', 'lago'), ('land', 'tierra'),
             ('language', 'idioma'), ('law', 'ley'), ('leg', 'pierna'), ('level', 'nivel'), ('lie', 'mentira'),
             ('life', 'vida'), ('light', 'luz'), ('line', 'línea'), ('list', 'lista'), ('machine', 'máquina'),
             ('man', 'hombre'), ('map', 'mapa'), ('material', 'material'), ('meat', 'carne'),
             ('middle', 'medio'), ('mile', 'milla'), ('milk', 'leche'), ('mind', 'mente'), ('minute', 'minuto'),
             ('money', 'dinero'), ('month', 'mes'), ('moon', 'luna'), ('mouth', 'boca'), ('music', 'música'),
             ('nation', 'nación'), ('night', 'noche'), ('nose', 'nariz'), ('note', 'nota'), ('number', 'número'),
             ('object', 'objeto'), ('ocean', 'océano'), ('office', 'oficina'), ('oil', 'aceite, petróleo'),
             ('page', 'página'), ('pair', 'par'), ('paper', 'papel'), ('paragraph', 'párrafo'), ('park', 'parque'),
             ('part', 'parte'), ('party', 'fiesta, partido'), ('past', 'pasado'),
             ('person', 'persona, gente'), ('pound', 'libra'), ('president', 'presidente'),
             ('problem', 'problema'), ('product', 'producto'), ('property', 'propiedad'), ('question', 'pregunta'),
             ('race', 'carrera'), ('radio', 'radio'), ('rain', 'lluvia'), ('reason', 'razón'), ('record', 'récord'),
             ('region', 'región'), ('ring', 'anillo'), ('river', 'río'), ('road', 'camino'), ('rock', 'roca'),
             ('row', 'fila'), ('rule', 'regla'), ('sand', 'arena'), ('school', 'escuela'), ('science', 'ciencia'),
             ('sea', 'mar'), ('seat', 'asiento'), ('second', 'segundo'), ('sentence', 'frase'), ('set', 'set, serie'),
             ('side', 'lado'), ('sign', 'señal, signo'), ('sister', 'hermana'), ('size', 'talla, tamaño'),
             ('skin', 'piel'), ('snow', 'nieve'), ('soldier', 'soldado'), ('solution', 'solución'),
             ('son', 'hijo (masculino)'), ('spring', 'primavera'), ('square', 'cuadrado, plaza'), ('star', 'estrella'),
             ('state', 'estado'), ('stop', 'parada'), ('street', 'calle'), ('student', 'estudiante'),
             ('sugar', 'azúcar'), ('sun', 'sol'), ('village', 'pueblo'), ('vowel', 'vocal (a, e, i, o, u)'),
             ('war', 'guerra'), ('weather', 'tiempo (clima)'), ('weight', 'peso'), ('wife', 'esposa'),
             ('window', 'ventana'), ('winter', 'invierno'), ('woman', 'mujer'), ('word', 'palabra'),
             ('world', 'mundo'), ('year', 'año')]
    imin = 0
    imax = 20

    def seltab(event):
        corte = int(event.widget.get())
        if corte == 1:
            imin = 0
            imax = 20
        elif corte == 2:
            imin = 20
            imax = 40
        elif corte == 3:
            imin = 40
            imax = 60
        elif corte == 4:
            imin = 60
            imax = 80
        elif corte == 5:
            imin = 80
            imax = 100
        elif corte == 6:
            imin = 100
            imax = 120
        elif corte == 7:
            imin = 120
            imax = 140
        elif corte == 8:
            imin = 140
            imax = 160
        elif corte == 9:
            imin = 160
            imax = 180
        else:
            imin = 180
            imax = 200
        for widget in tablas2.winfo_children():
            widget.destroy()
        t = TablaLabel(tablas2, imin, imax, lista, tci, tce)

    listas.bind("<<ComboboxSelected>>", seltab)
    t = TablaLabel(tablas2, imin, imax, lista, tci, tce)
    tablas1.pack()
    tablas2.pack()

    secundaria.mainloop()


# Ventana principal
principal = Tk()
width = principal.winfo_screenwidth()
height = principal.winfo_screenheight()
principal.geometry("%dx%d" % (width, height))
principal.config(bg="black")
principal.title("Software para aprender ingles.")
CR = Frame(principal)
CR.config(bg = "black")

Pres = Label(principal, text="Nuevo software para aprender inglés.", fg="white", bg="black", font="Courier 24 bold")
Pres.pack()
VerRegBot = Button(principal, text="Verbos regulares (200)", fg="white", bg="black", font="Courier 16 bold",
                   relief=SUNKEN, activeforeground="black", bd="12", command=verreg, width=24)
VerRegBot.pack(pady=4)
VerIrrBot = Button(principal, text="Verbos irregulares (154)", fg="white", bg="black", font="Courier 16 bold",
                   relief=SUNKEN, activeforeground="black", bd="12", command=verirr, width=24)
VerIrrBot.pack(pady=4)
VerPhrBot = Button(principal, text="Verbos compuestos (150)", fg="white", bg="black", font="Courier 16 bold",
                   relief=SUNKEN, activeforeground="black", bd="12", command=verphr, width=24)
VerPhrBot.pack(pady=4)
VerSusBot = Button(principal, text="Sustantivos (200)", fg="white", bg="black", font="Courier 16 bold",
                   relief=SUNKEN, activeforeground="black", bd="12", command=sus, width=24)
VerSusBot.pack(pady=4)
VerCr3Bot = Label(CR, text="Creative Commons contain BY and NC", fg="white", bg="black", font="Courier 8 bold",
                    activeforeground="black", bd="12")
VerCr3Bot.pack(side = BOTTOM)
VerCr2Bot = Label(CR, text="©2017-2022 Alejandro Jassan Rea Rivera", fg="white", bg="black", font="Courier 8 bold",
                    activeforeground="black", bd="12")
VerCr2Bot.pack(side = BOTTOM)
VerCr1Bot = Label(CR, text="Powered by GNU/GPL(MX) and CC", fg="white", bg="black", font="Courier 8 bold",
                    activeforeground="black", bd="12")
VerCr1Bot.pack(side = BOTTOM)
CR.pack(side = BOTTOM)

principal.mainloop()
